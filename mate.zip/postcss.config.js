export default {
  from: undefined,
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
